#include<stdio.h>
#include<stdlib.h>

int main(void){

    int i = 1;
    while(i<=10){
        printf("%d   %d   %d\n", i, i, i);
        i++;
    }

    system("Pause");
    return 0;
}